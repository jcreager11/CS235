#include "bst.h"

using namespace std;

void wordCount();