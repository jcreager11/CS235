#include <string>
using namespace std;

#ifndef HUFFMAN_H
#define HUFFMAN_H

void huffman();
void huffman(string &);

#endif