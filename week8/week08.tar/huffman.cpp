#include <string>
#include "huffman.h"
using namespace std;

void huffman()
{

}

void huffman(string & filename)
{

}